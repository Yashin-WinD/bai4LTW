<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh Sửa Danh Mục</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        body {
            background-color: #f3f4f6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 480px;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            color: #ffffff;
            padding: 24px 30px;
        }

        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .card-header p {
            font-size: 13px;
            color: #dbeafe;
            margin-top: 4px;
        }

        .card-body {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 22px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 14px;
            font-size: 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            transition: all 0.2s ease;
            outline: none;
        }

        .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
        }

        /* Khung hiển thị ảnh hiện tại */
        .current-image-box {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 16px;
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }

        .current-image-box img {
            width: 64px;
            height: 64px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
        }

        .current-image-info {
            font-size: 13px;
            color: #64748b;
        }

        /* Khung chọn file upload mới */
        .file-upload-box {
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            padding: 18px;
            text-align: center;
            background-color: #fafafa;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }

        .file-upload-box:hover {
            border-color: #2563eb;
            background-color: #eff6ff;
        }

        .file-upload-box input[type="file"] {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        .file-upload-text {
            font-size: 13px;
            color: #6b7280;
        }

        .file-upload-text span {
            color: #2563eb;
            font-weight: 600;
        }

        .img-preview {
            display: none;
            max-width: 80px;
            max-height: 80px;
            margin: 12px auto 0;
            border-radius: 8px;
            object-fit: cover;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 10px;
        }

        .btn {
            flex: 1;
            padding: 12px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background-color: #2563eb;
            color: white;
        }

        .btn-primary:hover {
            background-color: #1d4ed8;
        }

        .btn-secondary {
            background-color: #f3f4f6;
            color: #4b5563;
            border: 1px solid #d1d5db;
        }

        .btn-secondary:hover {
            background-color: #e5e7eb;
        }
    </style>
</head>
<body>

    <div class="card">
        <div class="card-header">
            <h2>Chỉnh Sửa Danh Mục</h2>
            <p>Cập nhật thông tin chi tiết cho danh mục #${category.id}</p>
        </div>

        <div class="card-body">
            <form action="${pageContext.request.contextPath}/admin/category/edit" 
                  method="post" 
                  enctype="multipart/form-data">
                
                <!-- ID ẩn gửi về server -->
                <input type="hidden" name="id" value="${category.id}" />

                <div class="form-group">
                    <label for="name">Tên danh mục <span style="color: #ef4444;">*</span></label>
                    <input type="text" id="name" name="name" class="form-control" 
                           value="${category.catename != null ? category.catename : category.name}" 
                           required placeholder="Nhập tên danh mục..." />
                </div>

                <div class="form-group">
                    <label>Ảnh đại diện hiện tại</label>
                    <c:choose>
                        <c:when test="${not empty category.icon}">
                            <div class="current-image-box">
                                <img src="${pageContext.request.contextPath}/image?fname=${category.icon}" alt="Icon hiện tại" />
                                <div class="current-image-info">
                                    <strong style="color: #1e293b;">Đang hiển thị</strong><br/>
                                    <span>Chọn ảnh mới bên dưới nếu muốn thay thế</span>
                                </div>
                            </div>
                        </c:when>
                        <c:otherwise>
                            <div class="current-image-box">
                                <div class="current-image-info">
                                    <i>(Danh mục này chưa có ảnh đại diện)</i>
                                </div>
                            </div>
                        </c:otherwise>
                    </c:choose>
                </div>

                <div class="form-group">
                    <label>Tải ảnh mới (Tùy chọn)</label>
                    <div class="file-upload-box">
                        <input type="file" id="icon" name="icon" accept="image/*" onchange="previewImage(event)" />
                        <div class="file-upload-text">
                            📁 <span>Bấm để tải ảnh thay thế</span>
                            <br><small style="color: #9ca3af; font-size: 11px;">Bỏ qua nếu muốn giữ lại ảnh cũ</small>
                        </div>
                        <img id="imagePreview" class="img-preview" alt="Xem trước ảnh mới" />
                    </div>
                </div>

                <div class="form-actions">
                    <a href="${pageContext.request.contextPath}/admin/category/list" class="btn btn-secondary">
                        Hủy bỏ
                    </a>
                    <button type="submit" class="btn btn-primary">
                        Lưu thay đổi
                    </button>
                </div>

            </form>
        </div>
    </div>

    <script>
        function previewImage(event) {
            const input = event.target;
            const preview = document.getElementById('imagePreview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            } else {
                preview.src = '';
                preview.style.display = 'none';
            }
        }
    </script>

</body>
</html>