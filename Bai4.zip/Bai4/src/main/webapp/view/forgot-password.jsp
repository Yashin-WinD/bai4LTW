<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quên mật khẩu</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
</head>
<body class="auth-wrap">
	<div class="auth-card">
		<h2 style="text-align:center;margin-bottom:8px">Quên mật khẩu</h2>
		<p class="muted" style="text-align:center;margin-bottom:18px">Nhập username hoặc email đã đăng ký, chúng tôi sẽ gửi OTP để đặt lại mật khẩu</p>
		<c:if test="${not empty alert}"><div class="alert-error">${alert}</div></c:if>
		<c:if test="${not empty message}"><div class="alert-ok">${message}</div></c:if>
		<form action="${pageContext.request.contextPath}/forgot-password" method="post">
			<div class="form-group">
				<label>Username hoặc Email</label>
				<input class="form-control" type="text" name="key" required autofocus>
			</div>
			<button class="btn btn-block" type="submit">Gửi OTP</button>
		</form>
		<p style="margin-top:16px;text-align:center">
			<a href="${pageContext.request.contextPath}/login">Quay lại đăng nhập</a> ·
			<a href="${pageContext.request.contextPath}/home">Trang chủ</a>
		</p>
	</div>
</body>
</html>
