<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Xác nhận OTP</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
</head>
<body class="auth-wrap">
	<div class="auth-card">
		<h2 style="text-align:center;margin-bottom:8px">Nhập mã OTP</h2>
		<p class="muted" style="text-align:center;margin-bottom:18px">
			Mã đã gửi tới <strong>${sessionScope.otpUser}</strong> (5 phút)
		</p>
		<c:if test="${not empty alert}"><div class="alert-error">${alert}</div></c:if>
		<c:if test="${not empty message}"><div class="alert-ok">${message}</div></c:if>
		<form action="${pageContext.request.contextPath}/verify-otp" method="post">
			<div class="form-group">
				<label>OTP 6 số</label>
				<input class="form-control" name="otp" maxlength="6" required>
			</div>
			<button class="btn btn-block" type="submit">Xác nhận</button>
		</form>
		<form action="${pageContext.request.contextPath}/verify-otp" method="post" style="margin-top:10px">
			<input type="hidden" name="resend" value="1">
			<button class="btn btn-block" type="submit" style="background:#6b7280">Gửi lại OTP</button>
		</form>
	</div>
</body>
</html>
