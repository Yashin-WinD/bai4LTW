<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
    <title>Cập nhật thông tin cá nhân</title>
</head>
<body>
    <div class="container mt-4">
        <h2>Thông tin tài khoản</h2>
        
        <c:if test="${not empty message}">
            <div class="alert alert-success">${message}</div>
        </c:if>

        <form action="${pageContext.request.contextPath}/user/profile" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Họ và tên</label>
                <input type="text" class="form-control" name="fullname" value="${user.fullname}" required />
            </div>

            <div class="mb-3">
                <label class="form-label">Số điện thoại</label>
                <input type="text" class="form-control" name="phone" value="${user.phone}" required />
            </div>

            <div class="mb-3">
                <label class="form-label">Ảnh đại diện</label>
                <input type="file" class="form-control" name="images" />
                <c:if test="${not empty user.images}">
                    <div class="mt-2">
                        <img src="${pageContext.request.contextPath}/image?fname=${user.images}" width="120" class="img-thumbnail" />
                    </div>
                </c:if>
            </div>

            <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
        </form>
    </div>
</body>
</html>