<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>${product.name}</title>
</head>
<body>
<jsp:include page="/view/shop-header.jsp"/>
<div class="container">
	<p class="muted" style="margin-bottom:12px">
		<a href="${pageContext.request.contextPath}/home">Trang chủ</a> /
		<a href="${pageContext.request.contextPath}/product">Sản phẩm</a> /
		${product.name}
	</p>
	<div class="detail">
		<div>
			<c:choose>
				<c:when test="${not empty product.image}">
					<img src="${pageContext.request.contextPath}/image?fname=${product.image}" alt="${product.name}">
				</c:when>
				<c:otherwise>
					<div class="thumb" style="height:320px;border-radius:12px"></div>
				</c:otherwise>
			</c:choose>
		</div>
		<div>
			<h2>${product.name}</h2>
			<p class="muted" style="margin:8px 0">Danh mục: ${product.category.catename}</p>
			<p class="price" style="font-size:24px;margin:12px 0">
				<fmt:formatNumber value="${product.price}" type="number"/> đ
			</p>
			<p>Số lượng: ${product.amount}</p>
			<p style="margin-top:16px;white-space:pre-line">${product.description}</p>
			<p style="margin-top:20px">
				<a class="btn" href="${pageContext.request.contextPath}/product">Xem tất cả sản phẩm</a>
			</p>
		</div>
	</div>
</div>
</body>
</html>
