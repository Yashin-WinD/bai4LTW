<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý danh mục</title>
    <style>
        .btn-add {
            display: inline-block;
            margin-bottom: 15px;
            padding: 8px 16px;
            background-color: #4f46e5;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .btn-add:hover { background-color: #4338ca; }
    </style>
</head>
<body style="padding: 20px; font-family: sans-serif;">

    <h2>Danh sách danh mục</h2>
    
    <%-- NÚT THÊM DANH MỤC MỚI --%>
    <a href="${pageContext.request.contextPath}/admin/category/add" class="btn-add">+ Thêm danh mục mới</a>

    <table border="1" cellpadding="8" cellspacing="0" style="width: 100%; text-align: center; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #f3f4f6;">
                <th>STT</th>
                <th>Mã danh mục</th>
                <th>Tên danh mục</th>
                <th>Hình ảnh</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${cateList}" var="cate" varStatus="STT">
                <tr>
                    <td>${STT.index + 1}</td>
                    <td>${cate.id}</td>
                    <td>${cate.catename}</td> 
                    <td>
                        <c:if test="${not empty cate.icon}">
                            <img src="${pageContext.request.contextPath}/image?fname=${cate.icon}" width="80" height="80" alt="Icon"/>
                        </c:if>
                    </td>
                    <td>
                        <a href="${pageContext.request.contextPath}/admin/category/edit?id=${cate.id}">Sửa</a>
                        |
                        <a href="${pageContext.request.contextPath}/admin/category/delete?id=${cate.id}" 
                           onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục này không?');">Xóa</a>
                    </td>
                </tr>
            </c:forEach>
            
            <c:if test="${empty cateList}">
                <tr>
                    <td colspan="5" style="color: #6b7280; padding: 20px;">
                        Chưa có dữ liệu. Vui lòng bấm nút "Thêm danh mục mới" ở trên để tạo!
                    </td>
                </tr>
            </c:if>
        </tbody>
    </table>

</body>
</html>