<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đặt lại mật khẩu</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
</head>
<body class="auth-wrap">
	<div class="auth-card">
		<h2 style="text-align:center;margin-bottom:8px">Đặt lại mật khẩu</h2>
		<p class="muted" style="text-align:center;margin-bottom:18px">Nhập mật khẩu mới cho tài khoản của bạn</p>
		<c:if test="${not empty alert}"><div class="alert-error">${alert}</div></c:if>
		<form action="${pageContext.request.contextPath}/reset-password" method="post">
			<div class="form-group">
				<label>Mật khẩu mới</label>
				<input class="form-control" type="password" name="password" required autofocus>
			</div>
			<div class="form-group">
				<label>Xác nhận mật khẩu</label>
				<input class="form-control" type="password" name="confirm" required>
			</div>
			<button class="btn btn-block" type="submit">Đặt lại mật khẩu</button>
		</form>
		<p style="margin-top:16px;text-align:center">
			<a href="${pageContext.request.contextPath}/login">Quay lại đăng nhập</a>
		</p>
	</div>
</body>
</html>
