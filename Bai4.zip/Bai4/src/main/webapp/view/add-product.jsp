<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Sản Phẩm Mới</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        body {
            background-color: #f3f4f6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 560px;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%);
            color: #ffffff;
            padding: 24px 30px;
        }

        .card-header h2 { font-size: 20px; font-weight: 600; }
        .card-header p { font-size: 13px; color: #e0e7ff; margin-top: 4px; }

        .card-body { padding: 30px; }

        .form-group { margin-bottom: 22px; }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 14px;
            font-size: 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            outline: none;
        }

        .form-control:focus {
            border-color: #4f46e5;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
        }

        textarea.form-control { resize: vertical; min-height: 90px; }

        .row-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .file-upload-box {
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            background-color: #fafafa;
            cursor: pointer;
            position: relative;
        }

        .file-upload-box:hover {
            border-color: #4f46e5;
            background-color: #f5f3ff;
        }

        .file-upload-box input[type="file"] {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        .file-upload-text { font-size: 13px; color: #6b7280; }
        .file-upload-text span { color: #4f46e5; font-weight: 600; }

        .img-preview {
            display: none;
            max-width: 100px;
            max-height: 100px;
            margin: 12px auto 0;
            border-radius: 8px;
            object-fit: cover;
            border: 1px solid #e5e7eb;
        }

        .form-actions { display: flex; gap: 12px; margin-top: 10px; }

        .btn {
            flex: 1;
            padding: 12px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }

        .btn-primary { background-color: #4f46e5; color: white; }
        .btn-primary:hover { background-color: #4338ca; }

        .btn-secondary {
            background-color: #f3f4f6;
            color: #4b5563;
            border: 1px solid #d1d5db;
        }
        .btn-secondary:hover { background-color: #e5e7eb; }
    </style>
</head>
<body>

    <div class="card">
        <div class="card-header">
            <h2>Thêm Sản Phẩm Mới</h2>
            <p>Điền thông tin bên dưới để tạo sản phẩm</p>
        </div>

        <div class="card-body">
            <form action="${pageContext.request.contextPath}/admin/product/add"
                  method="post"
                  enctype="multipart/form-data">

                <div class="form-group">
                    <label for="name">Tên sản phẩm <span style="color:#ef4444;">*</span></label>
                    <input type="text" id="name" name="name" class="form-control"
                           required placeholder="Ví dụ: iPhone 17 Pro Max" />
                </div>

                <div class="form-group">
                    <label for="description">Mô tả</label>
                    <textarea id="description" name="description" class="form-control"
                              placeholder="Mô tả chi tiết sản phẩm..."></textarea>
                </div>

                <div class="row-2">
                    <div class="form-group">
                        <label for="price">Giá bán (đ) <span style="color:#ef4444;">*</span></label>
                        <input type="number" step="0.01" min="0" id="price" name="price" class="form-control"
                               required placeholder="0" />
                    </div>
                    <div class="form-group">
                        <label for="amount">Số lượng</label>
                        <input type="number" min="0" id="amount" name="amount" class="form-control"
                               placeholder="0" />
                    </div>
                </div>

                <div class="form-group">
                    <label for="categoryId">Danh mục</label>
                    <select id="categoryId" name="categoryId" class="form-control">
                        <option value="">-- Chọn danh mục --</option>
                        <c:forEach items="${categories}" var="cate">
                            <option value="${cate.id}">${cate.catename}</option>
                        </c:forEach>
                    </select>
                </div>

                <div class="form-group">
                    <label>Hình ảnh sản phẩm</label>
                    <div class="file-upload-box">
                        <input type="file" id="image" name="image" accept="image/*" onchange="previewImage(event)" />
                        <div class="file-upload-text">
                            📁 <span>Bấm để chọn ảnh</span> hoặc kéo thả vào đây
                            <br><small style="color:#9ca3af;font-size:11px;">Hỗ trợ PNG, JPG, WEBP</small>
                        </div>
                        <img id="imagePreview" class="img-preview" alt="Xem trước ảnh" />
                    </div>
                </div>

                <div class="form-actions">
                    <a href="${pageContext.request.contextPath}/admin/product/list" class="btn btn-secondary">
                        Hủy bỏ
                    </a>
                    <button type="submit" class="btn btn-primary">
                        Thêm sản phẩm
                    </button>
                </div>

            </form>
        </div>
    </div>

    <script>
        function previewImage(event) {
            const input = event.target;
            const preview = document.getElementById('imagePreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            } else {
                preview.src = '';
                preview.style.display = 'none';
            }
        }
    </script>

</body>
</html>
