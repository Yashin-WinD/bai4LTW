<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng nhập</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
</head>
<body class="auth-wrap">
	<div class="auth-card">
		<h2 style="text-align:center;margin-bottom:8px">Đăng nhập</h2>
		<p class="muted" style="text-align:center;margin-bottom:18px">Nhập tài khoản đã kích hoạt OTP</p>
		<c:if test="${not empty alert}"><div class="alert-error">${alert}</div></c:if>
		<c:if test="${not empty success}"><div class="alert-ok">${success}</div></c:if>
		<form action="${pageContext.request.contextPath}/login" method="post">
			<div class="form-group">
				<label>Tên đăng nhập</label>
				<input class="form-control" type="text" name="username" value="${username}" required autofocus>
			</div>
			<div class="form-group">
				<label>Mật khẩu</label>
				<input class="form-control" type="password" name="password" required>
			</div>
			<div class="form-group">
				<label><input type="checkbox" name="remember"> Ghi nhớ đăng nhập</label>
			</div>
			<button class="btn btn-block" type="submit">Đăng nhập</button>
		</form>
		<p style="margin-top:16px;text-align:center">
			<a href="${pageContext.request.contextPath}/register">Đăng ký</a> ·
			<a href="${pageContext.request.contextPath}/forgot-password">Quên mật khẩu</a> ·
			<a href="${pageContext.request.contextPath}/home">Trang chủ</a>
		</p>
	</div>
</body>
</html>
