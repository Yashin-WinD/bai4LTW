<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Hướng dẫn Upload Multipart</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
</head>
<body>
<jsp:include page="/view/shop-header.jsp"/>
<div class="container">
	<h2 class="page-title">Hướng dẫn Upload Multipart</h2>
	<p>Trang này giải thích cách các form thêm/sửa danh mục và sản phẩm gửi file ảnh lên server:</p>
	<ol style="margin: 16px 0 16px 20px; line-height: 1.8;">
		<li>Form HTML phải khai báo <code>enctype="multipart/form-data"</code>.</li>
		<li>Servlet xử lý phải có annotation <code>@MultipartConfig</code>.</li>
		<li>Trong servlet, dùng <code>request.getPart("tenField")</code> để lấy file được gửi lên.</li>
		<li>Gọi <code>part.write(duongDan)</code> để lưu file vào thư mục upload trên server.</li>
		<li>Đường dẫn tương đối (ví dụ <code>category/xxx.jpg</code>) được lưu vào cơ sở dữ liệu,
			sau đó servlet <code>/image</code> (Downloadimagecontroller) đọc file từ thư mục upload
			và trả về cho trình duyệt khi hiển thị ảnh.</li>
	</ol>
	<p><a href="${pageContext.request.contextPath}/home">← Quay lại trang chủ</a></p>
</div>
</body>
</html>
