<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
<nav class="admin-nav">
	<a href="${pageContext.request.contextPath}/home">Trang chủ</a>
	<a href="${pageContext.request.contextPath}/admin/category/list">Danh mục</a>
	<a href="${pageContext.request.contextPath}/admin/product/list">Sản phẩm</a>
	<a href="${pageContext.request.contextPath}/guide/multipart">Hướng dẫn Multipart</a>
	<a href="${pageContext.request.contextPath}/logout">Đăng xuất</a>
</nav>
