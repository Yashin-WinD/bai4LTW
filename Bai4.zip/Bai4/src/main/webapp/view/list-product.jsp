<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý sản phẩm</title>
    <style>
        .btn-add {
            display: inline-block;
            margin-bottom: 15px;
            padding: 8px 16px;
            background-color: #4f46e5;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .btn-add:hover { background-color: #4338ca; }
    </style>
</head>
<body style="padding: 20px; font-family: sans-serif;">

    <h2>Danh sách sản phẩm</h2>

    <a href="${pageContext.request.contextPath}/admin/product/add" class="btn-add">+ Thêm sản phẩm mới</a>

    <table border="1" cellpadding="8" cellspacing="0" style="width: 100%; text-align: center; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #f3f4f6;">
                <th>STT</th>
                <th>Mã SP</th>
                <th>Hình ảnh</th>
                <th>Tên sản phẩm</th>
                <th>Danh mục</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${products}" var="p" varStatus="STT">
                <tr>
                    <td>${STT.index + 1}</td>
                    <td>${p.id}</td>
                    <td>
                        <c:if test="${not empty p.image}">
                            <img src="${pageContext.request.contextPath}/image?fname=${p.image}" width="60" height="60" alt="Ảnh sản phẩm"/>
                        </c:if>
                    </td>
                    <td>${p.name}</td>
                    <td>${p.category != null ? p.category.catename : ''}</td>
                    <td><fmt:formatNumber value="${p.price}" type="number"/> đ</td>
                    <td>${p.amount}</td>
                    <td>
                        <a href="${pageContext.request.contextPath}/admin/product/edit?id=${p.id}">Sửa</a>
                        |
                        <a href="${pageContext.request.contextPath}/admin/product/delete?id=${p.id}"
                           onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?');">Xóa</a>
                    </td>
                </tr>
            </c:forEach>

            <c:if test="${empty products}">
                <tr>
                    <td colspan="8" style="color: #6b7280; padding: 20px;">
                        Chưa có dữ liệu. Vui lòng bấm nút "Thêm sản phẩm mới" ở trên để tạo!
                    </td>
                </tr>
            </c:if>
        </tbody>
    </table>

</body>
</html>
