<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
<header class="site-header">
	<a class="brand" href="${pageContext.request.contextPath}/home">UTE Shop</a>
	<nav class="nav">
		<a href="${pageContext.request.contextPath}/home">Trang chủ</a>
		<a href="${pageContext.request.contextPath}/product">Sản phẩm</a>
		<a href="${pageContext.request.contextPath}/guide/multipart">Upload Multipart</a>
		<c:if test="${sessionScope.account.roleId == 1 || sessionScope.account.roleId == 2}">
			<a href="${pageContext.request.contextPath}/admin/category/list">QL Danh mục</a>
			<a href="${pageContext.request.contextPath}/admin/product/list">QL Sản phẩm</a>
		</c:if>
	</nav>
	<div>
		<c:choose>
			<c:when test="${empty sessionScope.account}">
				<a href="${pageContext.request.contextPath}/login">Đăng nhập</a>
				<span class="muted"> | </span>
				<a href="${pageContext.request.contextPath}/register">Đăng ký</a>
			</c:when>
			<c:otherwise>
				<strong>${sessionScope.account.fullName}</strong>
				<span class="muted"> | </span>
				<a href="${pageContext.request.contextPath}/logout">Đăng xuất</a>
			</c:otherwise>
		</c:choose>
	</div>
</header>
