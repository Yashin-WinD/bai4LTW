<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng ký</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/shop.css">
</head>
<body class="auth-wrap">
	<div class="auth-card">
		<h2 style="text-align:center;margin-bottom:8px">Đăng ký tài khoản</h2>
		<p class="muted" style="text-align:center;margin-bottom:18px">OTP kích hoạt sẽ gửi qua email</p>
		<c:if test="${not empty alert}"><div class="alert-error">${alert}</div></c:if>
		<form action="${pageContext.request.contextPath}/register" method="post">
			<div class="form-group">
				<label>Username</label>
				<input class="form-control" name="username" required>
			</div>
			<div class="form-group">
				<label>Email</label>
				<input class="form-control" type="email" name="email" required>
			</div>
			<div class="form-group">
				<label>Họ tên</label>
				<input class="form-control" name="fullName">
			</div>
			<div class="form-group">
				<label>Số điện thoại</label>
				<input class="form-control" name="phone">
			</div>
			<div class="form-group">
				<label>Mật khẩu</label>
				<input class="form-control" type="password" name="password" required>
			</div>
			<div class="form-group">
				<label>Xác nhận mật khẩu</label>
				<input class="form-control" type="password" name="confirm" required>
			</div>
			<button class="btn btn-block" type="submit">Đăng ký</button>
		</form>
		<p style="margin-top:16px;text-align:center">
			<a href="${pageContext.request.contextPath}/login">Đã có tài khoản? Đăng nhập</a>
		</p>
	</div>
</body>
</html>
