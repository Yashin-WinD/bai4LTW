package vn.ute.util;

import java.io.File;

public class Constant {
	/**
	 * Thư mục lưu file upload (icon danh mục, ảnh sản phẩm...).
	 * Trước đây bị hard-code là "E:\\upload" (chỉ chạy được trên Windows, ổ E:).
	 * Giờ cho phép override bằng system property "bainop1.upload.dir",
	 * nếu không có thì mặc định dùng thư mục tạm của hệ điều hành (chạy được
	 * trên Windows/Linux/macOS).
	 */
	public static final String DIR = System.getProperty("bainop1.upload.dir",
			System.getProperty("java.io.tmpdir") + File.separator + "bainop1-uploads");

	public static final int OTP_MINUTES = 5;
	public static final int PRODUCT_PAGE_SIZE = 6;
	public static final int HOME_NEWEST_SIZE = 10;

	/**
	 * SMTP Gmail: bật xác minh 2 bước rồi tạo "Mật khẩu ứng dụng" (App password)
	 * tại https://myaccount.google.com/apppasswords
	 */
	public static final String SMTP_HOST = "smtp.gmail.com";
	public static final String SMTP_PORT = "587";
	public static final String EMAIL_USER = "your.email@gmail.com";
	public static final String EMAIL_PASS = "your-app-password";
}
