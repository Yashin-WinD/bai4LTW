package vn.ute.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.ute.util.Constant;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/image") // Gọi dạng: /image?fname=category/123.jpg
public class Downloadimagecontroller extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String fileName = req.getParameter("fname");
        if (fileName == null || fileName.trim().isEmpty()) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        File baseDir = new File(Constant.DIR).getCanonicalFile();
        File file = new File(baseDir, fileName).getCanonicalFile();
        if (!file.getPath().startsWith(baseDir.getPath() + File.separator)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if (file.exists()) {

            String contentType = getServletContext().getMimeType(file.getName());
            if (contentType == null) {
                contentType = "image/jpeg";
            }
            resp.setContentType(contentType);


            try (FileInputStream fis = new FileInputStream(file)) {
                OutputStream out = resp.getOutputStream();
                byte[] buffer = new byte[8192];
                int len;
                while ((len = fis.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }
                out.flush();
            }
        } else {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
}