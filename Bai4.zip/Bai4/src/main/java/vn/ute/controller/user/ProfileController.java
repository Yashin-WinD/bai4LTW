package vn.ute.controller.user;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import vn.ute.model.User;
import vn.ute.service.Userservice;
import vn.ute.service.Impl.UserserviceImpl;
import vn.ute.util.Constant;

@WebServlet(urlPatterns = {"/user/profile"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class ProfileController extends HttpServlet {
    private Userservice userService = new UserserviceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        req.setAttribute("user", user);
        req.getRequestDispatcher("/view/user/profile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String fullname = req.getParameter("fullname");
        String phone = req.getParameter("phone");
        Part filePart = req.getPart("images");

        if (filePart != null && filePart.getSize() > 0) {
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            
            // Đặt lại tên file tránh trùng lặp
            String ext = fileName.substring(fileName.lastIndexOf("."));
            String newFileName = System.currentTimeMillis() + ext;
            
            String uploadPath = Constant.DIR + "/user"; // Ví dụ: C:/uploads/user
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            filePart.write(uploadPath + File.separator + newFileName);
            user.setImages(newFileName);
        }

        user.setUserName(fullname);
        user.setPhone(phone);

        userService.update(user);
        session.setAttribute("account", user); // Đăng ký lại thông tin mới vào Session

        req.setAttribute("message", "Cập nhật hồ sơ thành công!");
        req.setAttribute("user", user);
        req.getRequestDispatcher("/view/user/profile.jsp").forward(req, resp);
    }
}